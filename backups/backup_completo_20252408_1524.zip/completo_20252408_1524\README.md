# BACKUP COMPLETO DEL SISTEMA QR-ORDER
# Creado: Sun 24/08/2025 15:26:44.33
# Proyecto: osvgapxefsqqhltkabku

## Contenido del backup:

### 1. Base de datos completa
- Archivo: database_completo.sql
- Incluye: Tablas, datos, esquemas public/auth/storage
- Restaurar con: psql -f database_completo.sql

### 2. RLS Policies
- Archivo: rls_policies.sql  
- Incluye: Todas las políticas de seguridad
- Restaurar con: psql -f rls_policies.sql

### 3. Configuraciones del proyecto
- config.toml: Configuración de Supabase
- migrations/: Historial de migraciones  
- env.local.backup: Variables de entorno
- *.sql: Scripts SQL del proyecto

### 4. Edge Functions
- Carpeta: edge_functions/
- Incluye: Código de funciones serverless
- Restaurar con: supabase functions deploy

### 5. Información de Storage
- storage_info.md: Lista de buckets y archivos
- Nota: Descargar manualmente desde Supabase Dashboard

## Para restaurar completamente:
1. Restaurar BD: psql -f database_completo.sql
2. Aplicar policies: psql -f rls_policies.sql
3. Subir archivos de Storage manualmente
4. Redesplegar Edge Functions
5. Configurar variables de entorno

## Información técnica:
- Método: pg_dump con múltiples esquemas
- Versión PostgreSQL: 17
- Incluye: public, auth, storage schemas
