# INFORMACIÓN DE STORAGE
# Para descargar manualmente, usa Supabase Dashboard
# O implementa descarga con supabase CLI

Buckets conocidos en el proyecto:
- Imágenes de productos
- QR codes generados
- Archivos subidos por usuarios

Para descargar:
1. Instalar supabase CLI
2. supabase login
3. supabase storage ls
4. supabase storage download [bucket] [file]
